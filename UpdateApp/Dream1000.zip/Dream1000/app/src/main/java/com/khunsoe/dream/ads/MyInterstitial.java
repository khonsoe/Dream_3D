package com.khunsoe.dream.ads;


import android.app.Activity;
import android.content.Context;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import org.jetbrains.annotations.NotNull;

public class MyInterstitial {
    private InterstitialAd ggInterstitial;
    public static boolean isShowingAd = false;
    private final Context context;
    private boolean isLoading = false;

    public MyInterstitial(Context context) {
        this.context = context;
        loadAd();
    }

    public void loadAd() {
        if (context==null)
            return;
        if (ggInterstitial==null && !isLoading)
            fetchAd(context);
    }

    private void fetchAd(final Context context){
        System.out.println("Interstitial: fetchAd()");
        isLoading = true;
        InterstitialAd.load(context,AdsConstants.INTERSTITIAL,new AdRequest.Builder().build(),new InterstitialAdLoadCallback(){
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                // The mInterstitialAd reference will be null until
                // an ad is loaded.
                ggInterstitial = interstitialAd;
                listenAd(context);
                isLoading = false;
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                // Handle the error
                ggInterstitial = null;
                isLoading = false;
            }
        });
    }

    private void listenAd(final Context context){
        if (ggInterstitial==null)return;
        ggInterstitial.setFullScreenContentCallback(new FullScreenContentCallback(){
            @Override
            public void onAdDismissedFullScreenContent() {
                // Called when fullscreen content is dismissed.
                isShowingAd = false;
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NotNull com.google.android.gms.ads.AdError adError) {
                super.onAdFailedToShowFullScreenContent(adError);
                fetchAd(context);
            }

            @Override
            public void onAdShowedFullScreenContent() {
                // Called when fullscreen content is shown.
                // Make sure to set your reference to null so you don't
                // show it a second time.
                isShowingAd = true;
                ggInterstitial = null;
                fetchAd(context);
            }
        });
    }

    public void showAds(Activity activity) {
        if (ggInterstitial!=null) {
            ggInterstitial.show(activity);
            return;
        }

        loadAd();
    }
}
