package com.khunsoe.dream.utils;
import java.net.*;
import java.io.*;

public class JsonDown
{
	public static String download(String url){
		StringBuilder result=new StringBuilder();
		try
		{
			HttpURLConnection httpConn = ((HttpURLConnection)new URL(url).openConnection());
			BufferedReader reader = new BufferedReader(
				new InputStreamReader(httpConn.getInputStream()));
			String line = null;
			while ((line = reader.readLine()) != null)
				result.append(line).append("\n");

			reader.close();
			httpConn.disconnect();

		}
		catch (IOException e)
		{
			e.printStackTrace();
			return "";
		}

		return result.toString();
	}
}
