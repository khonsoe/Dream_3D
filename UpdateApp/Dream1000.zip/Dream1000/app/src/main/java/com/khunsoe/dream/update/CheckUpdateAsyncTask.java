package com.khunsoe.dream.update;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.widget.Toast;
import com.khunsoe.dream.async.TaskRunner;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class CheckUpdateAsyncTask {
    private final Activity activity;
    private final String json_url;

    public CheckUpdateAsyncTask(Activity activity, String json_url) {
        this.json_url = json_url;
        this.activity = activity;
        checkUpdate();
    }

    private void checkUpdate() {
        new TaskRunner().executeAsync(() -> fetch(json_url), new TaskRunner.Callback<String>() {
            @Override
            public void onTaskCompleted(String result) {
                if (result!=null)
                    letCheck(result);
            }

            @Override
            public void onTaskFailure(String error) {
                Toast.makeText(activity, error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void letCheck(String response){

        if (response!=null) {
            try {
                JSONObject obj = new JSONObject(response);
                String title = obj.getString("title");
                String msg = obj.getString("message");
                boolean force = obj.getBoolean("force");
                int versionCode = obj.getInt("versionCode");

                PackageManager manager = activity.getPackageManager();
                PackageInfo info;
                int currentVersion = 0;
                try {
                    info = manager.getPackageInfo(activity.getPackageName(), 0);
                    currentVersion = info.versionCode;
                } catch (PackageManager.NameNotFoundException e) {
                    e.printStackTrace();
                }

                if (versionCode > currentVersion){
                    letUpdate(title,msg, force);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }}

    private void letUpdate(final String title, final String message, final boolean force){

        final AlertDialog ad = new AlertDialog.Builder(activity).create();
        ad.setTitle(title);
        ad.setMessage(message);
        ad.setCancelable(!force);
        ad.setButton(AlertDialog.BUTTON_POSITIVE, "Play Store", (p1, p2) -> openInPlayStore());
        if (!force){
            ad.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancel", (p1, p2) -> {
                activity.finish();
            });
        }
        ad.show();
    }

    private void openInPlayStore(){
        activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + activity.getPackageName())));
    }

    private String fetch(String link)
    {
        String result = "";
        try {
            URL url = new URL(link);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK){
                InputStream inputStream = connection.getInputStream();
                ByteArrayOutputStream ba = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int length;

                while ((length = inputStream.read(buffer)) != -1){
                    ba.write(buffer, 0, length);
                }
                ba.close();
                result = ba.toString("UTF-8");
            }}
        catch (Exception e)
        {
            result = e.getMessage();
        }
        return result;
    }
}