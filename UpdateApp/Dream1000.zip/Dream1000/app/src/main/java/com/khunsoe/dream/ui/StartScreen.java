package com.khunsoe.dream.ui;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.khunsoe.dream.R;

import java.util.Timer;
import java.util.TimerTask;

public class StartScreen extends Activity {

    private static final int WAIT_TIME = 2500;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lg);

        Timer wt = new Timer();
        wt.schedule(new TimerTask() {
            @Override
            public void run() {
                StartScreen.this.runOnUiThread(() -> startMainActivity());
            }
        }, WAIT_TIME);
    }

    private void startMainActivity() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
