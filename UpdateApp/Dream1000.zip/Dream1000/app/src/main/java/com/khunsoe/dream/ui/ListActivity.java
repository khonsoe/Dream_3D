package com.khunsoe.dream.ui;

import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.*;
import android.os.*;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.*;
import androidx.appcompat.app.*;

import android.text.*;
import android.view.*;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.*;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.khunsoe.dream.async.TaskRunner;
import com.khunsoe.dream.utils.JsonDown;
import com.khunsoe.dream.model.PostItem;
import com.khunsoe.dream.R;
import com.khunsoe.dream.ads.MyInterstitial;
import com.khunsoe.dream.update.CheckUpdateAsyncTask;
import com.squareup.picasso.*;
import java.util.*;
import java.util.concurrent.Callable;

import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.gms.ads.MobileAds;

import android.os.Bundle;
import android.view.View;
import android.view.Menu;
import androidx.appcompat.app.AppCompatActivity;

import org.jetbrains.annotations.NotNull;

public abstract class ListActivity extends AppCompatActivity
{

	public abstract void processJson(String jsonString);
	public abstract boolean useGridLayout();
	public abstract String getFeedAddress();
	public abstract void _Options_Menu_Click(MenuItem item);
	private SwipeRefreshLayout mSwipeLayout;
	RecyclerView rv;
	FeedAdapter adapter;
	List<PostItem> posts,filteredposts;
	boolean online=true;
	String currentLink="";
	final int FONT_NONE=0;
	int currentFont=FONT_NONE;
	final String mapp="KHUN SOE ZAW THU";

	private ActionBarDrawerToggle mDrawerToggle;
	private NavigationView navigationView;
	private MyInterstitial interstitialAd;
	CoordinatorLayout coordinatorLayout;
	DrawerLayout mDrawerLayout;
	String nbs,nb, im;
	String nmb;
	Toolbar tb;

	public ProgressBar progressBar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		tb = findViewById(R.id.kr_toolbar);
		setSupportActionBar(tb);
		coordinatorLayout = findViewById(R.id.cc);

		new CheckUpdateAsyncTask(this, "https://raw.githubusercontent.com/khonsoe/Dream_3D/main/UpdateApp/Dream.json");

		navigationView = findViewById(R.id.navigation_view);

		mDrawerLayout = findViewById(R.id.drawer_layout);
		mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, 0, 0);
		//mDrawerLayout.setDrawerListener(mDrawerToggle);
		mDrawerLayout.addDrawerListener(mDrawerToggle);
		if (getSupportActionBar()!=null)
			getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		setupNV();

		assert navigationView != null;
		navigationView.setItemIconTintList(null);

		navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
			@Override
			public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
			{
				menuItem.setChecked(true);
				mDrawerLayout.closeDrawers();
				//_MenuItem_Click(menuItem.getItemId());
				_Options_Menu_Click(menuItem);
				return true;
			}
		});

		FloatingActionButton fab = findViewById(R.id.fab);
		fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				Intent intent =new Intent("android.intent.action.SEND");
				intent.setType("text/plain");
				//intent.putExtra("android.intent.extra.TEXT","Download Free App\nhttps://play.google.com/store/apps/details?id=com.khunarr.am\nThanks for your encouragement");
				intent.putExtra("android.intent.extra.TEXT","Free Download\n"+"http://play.google.com/store/apps/details?id=" + getPackageName() +"\nThank for your encouragement");
				startActivity(new Intent(Intent.createChooser(intent, getString(R.string.app_name))));
			}
		});

		MobileAds.initialize(this);
		interstitialAd = new MyInterstitial(this);
		mSwipeLayout = findViewById(R.id.swipeRefreshLayout);
		mSwipeLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				if(isOnline())
					refresh();
				else {
					mSwipeLayout.setRefreshing(false);
					net();
					//netError();
				}}
		});
		mSwipeLayout.setColorSchemeResources(
				R.color.refresh_progress_1,
				R.color.refresh_progress_2,
				R.color.refresh_progress_3);

		posts=new ArrayList<PostItem>();
		filteredposts=new ArrayList<PostItem>();
		rv=(RecyclerView)findViewById(R.id.recyclerview);
		if(useGridLayout()){
			rv.setLayoutManager(new GridLayoutManager(this,3));
		}else{
			rv.setLayoutManager(new LinearLayoutManager(this));
		}
		SharedPreferences sharedPreferences = getSharedPreferences("MyData", Context.MODE_PRIVATE);
		currentFont = sharedPreferences.getInt("font_main", 0);
		refresh();
	}


	private void setupNV()
	{
		navigationView.getMenu().clear();
		navigationView.inflateMenu(R.menu.navigation_menu);
	}

	protected void onPostCreate(Bundle savedInstanceState)
	{
		super.onPostCreate(savedInstanceState);
		mDrawerToggle.syncState();
	}

	@Override
	public void onConfigurationChanged(@NotNull Configuration newConfig)
	{
		super.onConfigurationChanged(newConfig);
		mDrawerToggle.onConfigurationChanged(newConfig);
	}
	public void net(){
		final Snackbar snack= Snackbar.make(coordinatorLayout,"",Snackbar.LENGTH_SHORT);
		View custom= getLayoutInflater().inflate(R.layout.snackbar_custom,null);
		progressBar = custom.findViewById(R.id.prog);
		Animation animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate_prog);
		progressBar.startAnimation(animation);
		snack.getView().setBackgroundColor(Color.TRANSPARENT);
		Snackbar.SnackbarLayout snackbarLayout = (Snackbar.SnackbarLayout) snack.getView();
		snackbarLayout.setPadding(0,0,0,0);
		(custom.findViewById(R.id.ty)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				refresh();
				progressBar.setCameraDistance(0);
				snack.dismiss();
			}
		});
		snackbarLayout.addView(custom,0);
		snack.show();
	}

	public void netError() {
		//Toast.makeText(getApplicationContext(),"No internet connection",Toast.LENGTH_SHORT).show();
		//ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		//NetworkInfo ni = cm.getActiveNetworkInfo();
		//if (ni == null) {
		//mDialog = new Dialog(ListActivity.this);
		final ProgressDialog pDialog = new ProgressDialog(ListActivity.this);
		pDialog.setIcon(R.drawable.net_error);
		pDialog.setProgress(ProgressDialog.STYLE_SPINNER);
		pDialog.setTitle(getString(R.string.net_error));
		pDialog.setMessage(getString(R.string.no_net));
		pDialog.setCancelable(false);
		pDialog.setButton(getString(R.string.try_again),new DialogInterface.OnClickListener(){
			@Override
			public void onClick(DialogInterface dialog,int which){
				refresh();
			}});
		//No.Button
		pDialog.setButton2("Cancel",new DialogInterface.OnClickListener(){
			@Override
			public void onClick(DialogInterface dialog,int which){
				pDialog.dismiss();
			}
		});
		pDialog.show();
	}

	public void refresh(){
		//adapter.reset();
		currentLink=getFeedAddress();

		tb.collapseActionView();
		if(isOnline()){
			online=true;
			download(currentLink);
		}else{
			online=false;
			net();
			//netError();
			//Toast.makeText(getApplicationContext(),"No internet connection",Toast.LENGTH_SHORT).show();

			try{
				processJson(getFromPrefs(currentLink));
				adapter=new FeedAdapter();
				rv.setAdapter(adapter);
			}catch(Exception e){
				Toast.makeText(this,e.toString(),Toast.LENGTH_SHORT).show();
			}
		}
	}


	public void saveToPrefs(String result){
		SharedPreferences sharedPreferences = getSharedPreferences("MyData", Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putString(currentLink,result);
		editor.apply();
	}

	public String getFromPrefs(String key){

		SharedPreferences sharedPreferences = getSharedPreferences("MyData", Context.MODE_PRIVATE);
		return sharedPreferences.getString(currentLink,"");
	}

	private void download(String url){
		mSwipeLayout.setRefreshing(true);
		new TaskRunner().executeAsync(() -> JsonDown.download(url), new TaskRunner.Callback<String>() {
			@Override
			public void onTaskCompleted(String result) {
				processJson(result);
				saveToPrefs(result);
				mSwipeLayout.setRefreshing(false);
				adapter = new FeedAdapter();
				rv.setAdapter(adapter);
			}

			@Override
			public void onTaskFailure(String error) {
				Toast.makeText(ListActivity.this, ""+error, Toast.LENGTH_SHORT).show();
			}
		});
	}

	protected boolean isOnline() {
		ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		return netInfo != null && netInfo.isConnectedOrConnecting();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.main_menu,menu);
		MenuItem myActionMenuItem = menu.findItem(R.id.menu_search);
		SearchView sv = (SearchView) myActionMenuItem.getActionView();
		sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
			@Override
			public boolean onQueryTextSubmit(String p1)
			{
				return false;
			}

			@Override
			public boolean onQueryTextChange(String p1)
			{
				adapter.filter(p1);
				return false;
			}
		});
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		int id = item.getItemId();
		if(id==android.R.id.home){
			mDrawerLayout.openDrawer(GravityCompat.START);
			return true;
		}

		/*if(item.getItemId()==R.id.menu_sr){
			refresh();
		}*/
		else{
			_Options_Menu_Click(item);
		}
		return super.onOptionsItemSelected(item);
	}

	public void addItem(PostItem item){
		posts.add(item);
	}

	public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.ViewHolder>
	{
		@Override
		public FeedAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
		{
			View v=getLayoutInflater().inflate(R.layout.list_adapter,p1,false);
			//Animation animator=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.bounce);
			//v.startAnimation(animator);
			return new ViewHolder(v);
		}

		public String getEngNumber(String n) {
			StringBuilder res = new StringBuilder();
			for (String s:n.split("")){
				res.append(replace(s));
			}
			return res.toString();
		}

		private String replace(String str){
			switch (str){
				case "၀":return "0";
				case "၁":return "1";
				case "၂":return "2";
				case "၃":return "3";
				case "၄":return "4";
				case "၅":return "5";
				case "၆":return "6";
				case "၇":return "7";
				case "၈":return "8";
				case "၉":return "9";
			}
			return str;
		}

		public void filter(String charText){
			charText = getEngNumber(charText.toLowerCase());
			filteredposts.clear();
			if (charText.length()==0){
				filteredposts.addAll(posts);
			}else{
				for (PostItem pi : posts){
					if(pi.nb.toLowerCase().contains(charText))
					{
						filteredposts.add(pi);
					}
				}
				for (PostItem pi : posts){
					if(pi.nmb.toLowerCase().contains(charText))
					{
						filteredposts.add(pi);
					}
				}
				for (PostItem pi : posts){
					if(pi.nbs.toLowerCase().contains(charText))
					{
						filteredposts.add(pi);
					}
				}
			}
			notifyDataSetChanged();
		}

		@Override
		public int getItemCount()
		{
			return filteredposts.size();
		}

		@Override
		public void onBindViewHolder(FeedAdapter.ViewHolder p1, int p2)
		{
			if((filteredposts.get(p2).im.length()>0)&&(online)){
				Picasso
						.with(getApplicationContext())
						.load(Html.fromHtml(filteredposts.get(p2).im).toString())
						.into(p1.imv);
			}else{
				//p1.imv.setImageResource(R.drawable.ic_cn);
			}
			p1.tvs.setText(filteredposts.get(p2).nbs);
			p1.tvb.setText(filteredposts.get(p2).nb);
			p1.tvnm.setText(filteredposts.get(p2).nmb);
		}

		public PostItem getItem(int pos){
			return filteredposts.get(pos);
		}


		public void reset()
		{
			posts.clear();
			filteredposts.clear();
			notifyDataSetChanged();
		}

		public FeedAdapter()
		{
			super();
			filteredposts= new ArrayList<>();
			filteredposts.addAll(posts);
		}

		public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
			ImageView imv;
			TextView tvs,tvb, tvnm, bbgg;
			Dialog mmDialog;
			Button Down;


			@Override
			public void onClick(View view) {

				Intent i = getIntent();
				//Intent i=new Intent(ListActivity.this, FontActivity.class);
				PostItem pi = filteredposts.get(getAdapterPosition());
				i.putExtra("nbs", pi.nbs);
				i.putExtra("nb", pi.nb);
				i.putExtra("nmb", pi.nmb);
				i.putExtra("im", pi.im);

				//////
				nbs = i.getStringExtra("nbs");
				nb = i.getStringExtra("nb");
				nmb = i.getStringExtra("nmb");
				im = i.getStringExtra("im");
				///////
				mmDialog = new Dialog(ListActivity.this, R.style.Dialog_MinWidth);
				mmDialog.setContentView(R.layout.dialog_custom);
				////
				Random random = new Random();
				int color = Color.argb(245, random.nextInt(246), random.nextInt(246), random.nextInt(246));
				tvs = mmDialog.findViewById(R.id.sigb);
				tvs.setText(nbs);
				tvs.setTextColor(color);

				tvb = mmDialog.findViewById(R.id.tvv);
				tvb.setText(nb);
				tvb.setTextColor(color);
				/////
				tvnm = mmDialog.findViewById(R.id.msg);
				tvnm.setText(nmb);
				//////
				imv = mmDialog.findViewById(R.id.im);
				int p2 = 0;
				if((filteredposts.get(p2).im.length()>0)&&(online)){
					Picasso
							.with(getApplicationContext())
							.load(im)
							.into(imv);
				}else{
					//imv.setImageResource(R.drawable.ic_cn);
				}
				mmDialog.setCancelable(false);
				Down = mmDialog.findViewById(R.id.down);
				Down.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						mmDialog.dismiss();
						showAD();
						//Toast.makeText(context, R.string.cancel, Toast.LENGTH_SHORT).show();
					}
				});
				//  if (!mDialog.isShowing()) {
				mmDialog.show();
				////////
			}

			public ViewHolder(View view)
			{

				super(view);
				Random random=new Random();
				int color = Color.argb(245, random.nextInt(246),random.nextInt(246),random.nextInt(246));
				imv=view.findViewById(R.id.ivItemImage);

				bbgg=view.findViewById(R.id.bbgg);
				GradientDrawable bg =new GradientDrawable();
				bg.setShape(GradientDrawable.OVAL);
				bg.setColor(color);
				bbgg.setBackground(bg);

				tvs=view.findViewById(R.id.siga);
				tvs.setTextColor(color);

				tvb=view.findViewById(R.id.num);
				tvb.setTextColor(color);

				tvnm=view.findViewById(R.id.nm);
				view.setOnClickListener(this);


			}
		}
	}

	public void showAD() {
		if (interstitialAd!=null)
			interstitialAd.showAds(this);
	}

	@Override
	public void onBackPressed() {
		final Dialog mDialog = new Dialog(ListActivity.this, R.style.Dialog_MinWidth);
		mDialog.setContentView(R.layout.ex_b);
		mDialog.setCancelable(true);
		TextView thank_t = mDialog.findViewById(R.id.exit_t);
		thank_t.setText(getString(R.string.exit));
		MaterialButton exit_c = mDialog.findViewById(R.id.cl_exit);
		mDialog.show();
		ImageView imvi = mDialog.findViewById(R.id.imview);
		Animation animator=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.bounce);
		imvi.startAnimation(animator);
		exit_c.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				ListActivity.this.finish();
				showAD();
				//Toast.makeText(MainActivity.this,getString(R.string.exit), Toast.LENGTH_SHORT).show();
			}
		});
		MaterialButton srue = mDialog.findViewById(R.id.srue);
		srue.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				srue();
				mDialog.dismiss();
				//Toast.makeText(MainActivity.this,getString(R.string.srue), Toast.LENGTH_SHORT).show();
			}
		});
		//  super.onBackPressed();
	}
	public void srue(){
		try {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
		} catch (android.content.ActivityNotFoundException anfe) {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
		}
	}
	public void moreApp(String pub){
		try {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=pub:"+ pub)));
		} catch (android.content.ActivityNotFoundException anfe) {
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/search?q=pub:"+ pub)));
		}
	}
}
